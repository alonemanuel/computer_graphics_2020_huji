alonemanuel
205894058

Shaharna13
313586877

Answer to Q1:
Before the triangles were flattened, each vertex's normal was an average of the normals of it's adjacent planes.
Each vertex was part of multiple planes, which gave each vertex a 'unique' normal. 
When coloring each plane's color and shading, it took into account the different normals of it's vertices, which resulted in a gradient-like color spread.

After falttening the triangles, vertex was connected to a single plane. This resulted in all vertices of a plane sharing the same normal (since there was no average to be taken - just the normal of the one plane).
Now, when calculating the shading and color of a plane, it has one normal to take into account - the normal that is 'shared' across its vertices.